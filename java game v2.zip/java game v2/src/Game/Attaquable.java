package Game;

public interface Attaquable {
	void attaquer(Personnage cible);
	void utiliserCompetence(Personnage cible);
}
